#
#Author: Gustav Jannering gusja113
#
import sqlite3
from flask import g

DATABASE = '/home/gusja113/TDDD97/Twidder/Server/database.db'


def connect_db():
    return sqlite3.connect(DATABASE)


def get_db():
    db = getattr(g, 'db', None)
    if db is None:
        db = g.db = connect_db()
    return db


# def add_message_to_user(user, message, writer):
#     c = get_db()
#     c.execute("insert into entries (name,message) values (?,?)", (name,message))
#     c.commit()


def add_user(email, password, fname, lname, gender, city, country):
    c = get_db()
    c.execute("insert into users (user_email, user_password, user_first_name, user_last_name, user_gender, user_city, user_country, user_messages) values (?,?,?,?,?,?,?,?)", (email, password, fname, lname, gender, city, country, " "))
    c.commit()


def add_online_user(token, user_email, private_key):
    c = get_db()
    c.cursor().execute("insert into online_users values (?,?,?)", (token, user_email, private_key))
    c.commit()


def get_user_by_email(user_email):
    c = get_db().cursor()
    c.execute('SELECT * FROM users WHERE user_email = ?', (user_email,))
    return c.fetchone()


def get_online_user_by_email(user_email):
    c = get_db().cursor()
    c.execute('SELECT * FROM online_users WHERE user_email = ?', (user_email,))
    return c.fetchone()


def get_online_user_by_token(token):
    c = get_db().cursor()
    c.execute('SELECT * FROM online_users WHERE user_token = ?', (token,))
    return c.fetchone()


def delete_online_user(token):
    c = get_db()
    c.cursor().execute('DELETE FROM online_users WHERE user_token = ?', (token,))
    c.commit()


def change_user_password(email, new_password):
    c = get_db()
    c.cursor().execute('UPDATE users SET user_password=? WHERE user_email=?', (new_password,email))
    c.commit()


def post_message(email, message):
    c = get_db()
    c.cursor().execute('UPDATE users SET user_messages=? WHERE user_email=?', (message,email))
    c.commit()


def delete_user(email):
    c = get_db()
    c.cursor().execute('DELETE FROM users WHERE user_email = ?', (email,))
    c.commit()


def add_file(filename, to_email, from_email):
    c = get_db()
    c.cursor().execute("insert into user_files values (?,?,?)", (filename, to_email, from_email))
    c.commit()


def add_profile_picture(filename, email):
    c = get_db()
    c.cursor().execute("insert into profile_pictures values (?,?)", (filename, email))
    c.commit()


def get_profile_piture(email):
    c = get_db().cursor()
    c.execute('SELECT * FROM profile_pictures WHERE email = ?', (email,))
    return c.fetchone()


def change_profile_picture(filename, email):
    c = get_db()
    c.cursor().execute('UPDATE profile_pictures SET filename=? WHERE email=?', (filename,email))
    c.commit()


def close():
    get_db().close()
