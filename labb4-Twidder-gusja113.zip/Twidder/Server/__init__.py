#
#Author: Gustav Jannering gusja113
#
from flask import Flask, jsonify, request

import database_helper
import random
import json
import views

app = Flask(__name__)


@app.before_request
def before_request():
    database_helper.connect_db()

@app.teardown_request
def teardown_request(exception):
    database_helper.close()

