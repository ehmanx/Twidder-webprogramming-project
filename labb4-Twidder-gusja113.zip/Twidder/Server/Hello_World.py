from flask import Flask
import database_helper
app = Flask(__name__)

@app.route('/')
def hello_world():
    x = database_helper.get_user_by_email("b@b.b")
    y = str(type(x))
    return y

if __name__ == '__main__':
    app.run()