//
//Author: Gustav Jannering (gusja113)
//
//

//
//Global Variables
//
var Socket;

//
//Display the correct view
//
displayView = function(){

    var View = document.getElementById("test");
    var Token = localStorage.getItem("Token");

    if(Token != null){
        View.innerHTML = document.getElementById("Profile_View").innerHTML;
        Disp_Info();
        Init();
    }
    else{
        View.innerHTML = document.getElementById("Welcome_View").innerHTML;

    }


}
//
//Window function
//
window.onload = function(){

    displayView();
}
//
// Init function for file upload in home tab
//
var Init = function() {
    var fileselect = document.getElementById("fileselect"),
        filedrag = document.getElementById("filedrag"),
        submitbutton = document.getElementById("submitbutton");


    // file select
    fileselect.addEventListener("change", FileSelectHandler, false);

    // is XHR2 available?
    var xhr = new XMLHttpRequest();
    if (xhr.upload) {

        // file drop
        filedrag.addEventListener("dragover", FileDragHover, false);
        filedrag.addEventListener("dragleave", FileDragHover, false);
        filedrag.addEventListener("drop", FileSelectHandler, false);
        filedrag.style.display = "block";

        // remove submit button
        submitbutton.style.display = "none";
    }
}
//
//Init function for profile picture upload in account tab
//
var Profile_Init = function() {
    var profile_fileselect = document.getElementById("profile_fileselect"),
        profile_filedrag = document.getElementById("profile_filedrag"),
        profile_submitbutton = document.getElementById("profile_submitbutton");


    // file select
    profile_fileselect.addEventListener("change", Profile_FileSelectHandler, false);

    // is XHR2 available?
    var xhr = new XMLHttpRequest();
    if (xhr.upload) {

        // file drop
        profile_filedrag.addEventListener("dragover", FileDragHover, false);
        profile_filedrag.addEventListener("dragleave", FileDragHover, false);
        profile_filedrag.addEventListener("drop", Profile_FileSelectHandler, false);
        profile_filedrag.style.display = "block";

        // remove submit button
        profile_submitbutton.style.display = "none";
    }
}
//
//Init function for file upload on another users wall
//
var User_Init = function() {
    console.log("success");
    var user_fileselect = document.getElementById("user_fileselect"),
        user_filedrag = document.getElementById("user_filedrag"),
        user_submitbutton = document.getElementById("user_submitbutton");


    // file select
    user_fileselect.addEventListener("change", User_FileSelectHandler, false);

    // is XHR2 available?
    var xhr = new XMLHttpRequest();
    if (xhr.upload) {

        // file drop
        user_filedrag.addEventListener("dragover", FileDragHover, false);
        user_filedrag.addEventListener("dragleave", FileDragHover, false);
        user_filedrag.addEventListener("drop", User_FileSelectHandler, false);
        user_filedrag.style.display = "block";

        // remove submit button
        user_submitbutton.style.display = "none";
    }
}
//
//
//
var FileDragHover = function(e) {
	e.stopPropagation();
	e.preventDefault();
	e.target.className = (e.type == "dragover" ? "hover" : "");
}
//
// function for uploading files fom home tab
//
var FileSelectHandler = function(e) {
    var Token = localStorage.getItem("Token");
	// cancel event and hover styling
	FileDragHover(e);

	// fetch FileList object
	var files = e.target.files || e.dataTransfer.files;

	// process all File objects
	for (var i = 0, f; f = files[i]; i++) {
		console.log(f.name);
        var To_email = document.getElementById("User_Email").innerHTML;
        console.log(To_email);
		Upload_File(f, Token, To_email);
	}

}
//
// function for uploading profile picture from account tab
//
var Profile_FileSelectHandler = function(e) {
    var Token = localStorage.getItem("Token");
	// cancel event and hover styling
	FileDragHover(e);

	// fetch FileList object
	var files = e.target.files || e.dataTransfer.files;

	// process all File objects
	for (var i = 0, f; f = files[i]; i++) {
		console.log(f.name);
		Profile_Image_Upload(f, Token);
	}

}
//
//function for uploading files to another users wall
//
var User_FileSelectHandler = function(e) {
    var Token = localStorage.getItem("Token");
	// cancel event and hover styling
	FileDragHover(e);

	// fetch FileList object
	var files = e.target.files || e.dataTransfer.files;

	// process all File objects
	for (var i = 0, f; f = files[i]; i++) {
        console.log(f.name);
         var To_email = document.getElementById("Found_User_Email").innerHTML;
        console.log(To_email);
		Upload_File(f, Token, To_email);
	}

}

//
// functions to allow users to copy user info into textboxes
//
var allowDrop = function(ev) {
    ev.preventDefault();
}

var drag =function(ev) {
    ev.dataTransfer.setData("text", document.getElementById(ev.target.id).innerHTML);
}

var drop = function(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
}
//
// Button functions bellow!
//

//
//Sign up button function
//
var Signup_Submit = function(formData){
    var Pass = formData.Password.value;
    var Re_Pass = formData.RE_Password.value;
    var Signup_Text = document.getElementById("Signup_Text");
    if (Pass.length >= 8){
        if (Re_Pass.length >= 8){
            if (Pass == Re_Pass){
                var Signup = {
                  email: formData.Email.value,
                  password: Pass,
                  firstname: formData.firstname.value,
                  familyname: formData.familyname.value,
                  gender: formData.Gender.value,
                  city: formData.City.value,
                  country: formData.Country.value
                };
                var xmlhttp = new XMLHttpRequest();
                xmlhttp.open("POST", "signup", true );//signup
                xmlhttp.setRequestHeader("Content-type", "application/json");
                xmlhttp.send(JSON.stringify(Signup));
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        var Signup_message = JSON.parse(xmlhttp.responseText);
                        Signup_Text.innerHTML =Signup_message.message;
                    }
                }
            }
            else{
                Signup_Text.innerHTML = "Invalid Password";
            }
        }
        else{
                Signup_Text.innerHTML = "Password needs to be 8 characters or longer";
        }

    }
    else{
                Signup_Text.innerHTML = "Password needs to be 8 characters or longer";
        }
}
//
//Sign in button function
//
var Signin_Submit = function(formData){

    var Email = formData.Login_Email.value;
    var Password = formData.Login_Password.value;

    var Signin = {"email": Email, "password": Password};
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("POST", "/signin", true );//signin
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify(Signin));
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
          var Response = JSON.parse(xmlhttp.responseText);
          if (Response["success"] == false){
              var Login_Text =document.getElementById("LogIn_Text");
              Login_Text.innerHTML = Response["message"];
          }
          else {
              localStorage.setItem("Token", Response["token"]);
              localStorage.setItem("Private_Key", Response["private_key"]);
              Socket = new WebSocket("ws://127.0.0.1:5000/ws");
              Socket.onopen = function(event) {
                  console.log("opened");
                  Socket.send(localStorage.getItem("Token"));
              }
              Socket.onmessage = function(event) {
                  console.log("message")
                  Signout_Submit();
                  Socket.close();
              }
              Socket.onclose = function () {
                  console.log("closed!");
              }

              displayView();
          }
      }

  }

}
//
//Change password button function
//
var Changepass_Submit = function(formData){

    var Old_Pass = formData.Old_Password.value;
    var New_Pass = formData.New_Password.value;
    var Private_Key =localStorage.getItem("Private_Key");

    if (Old_Pass == New_Pass){        Disp_Account_Tab();
        document.getElementById("Changepass_Text").innerHTML = "Use a new password please!";
    }
    else{
        if (New_Pass.length < 8){
            document.getElementById("Changepass_Text").innerHTML = "Password needs to be 8 characters or longer";
        }
        else{
            var Token = localStorage.getItem("Token");
            var Hash = Crypto.HMAC(Crypto.SHA1, Old_Pass + New_Pass, Private_Key);
            var Changepass = {"token": Token, "old_password":Old_Pass, "new_password":New_Pass, "hash": Hash};
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.open("POST", "/changepassword", true );//changepassword
            xmlhttp.setRequestHeader("Content-type", "application/json");
            xmlhttp.send(JSON.stringify(Changepass));
            xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        var Response = JSON.parse(xmlhttp.responseText);
                        document.getElementById("Changepass_Text").innerHTML = Response["message"];

                    }
            }
        }
    }

}
//
//Sign out button function
//
var Signout_Submit = function(){
    var Token = localStorage.getItem("Token");
    var Private_Key =localStorage.getItem("Private_Key");
    var Hash = Crypto.HMAC(Crypto.SHA1, Token, Private_Key);
    var Signout = {"token":Token, "hash": Hash};
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("POST", "/signout", true )//signout
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify(Signout));
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var Response = JSON.parse(xmlhttp.responseText)
            document.getElementById("Changepass_Text").innerHTML = Response["message"];
            if(Response["success"] = true){
                localStorage.removeItem("Token");
                displayView();
            }
        }
    }
}
//
//Post message button function
//
var Post_Submit = function(formData){
    var Message =formData.Message.value;
    var Private_Key =localStorage.getItem("Private_Key");
    var Token = localStorage.getItem("Token");
    var Get_Hash = Crypto.HMAC(Crypto.SHA1, Token, Private_Key);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "/getuserdatatoken?token=" + Token + "&hash=" + Get_Hash, true)//getueserdatabytoken
    xmlhttp.send(null);
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var User = JSON.parse(xmlhttp.responseText);
            Message += " - " + User["data"]["email"] + "\n";
            var Post_Hash = Crypto.HMAC(Crypto.SHA1, User["data"]["email"] + Message, Private_Key);
            var Message_obj = {"token":Token, "message":Message, "email":User["data"]["email"], "hash": Post_Hash};
            xmlhttp.open("POST", "postmessage", true ); //postmessage
            xmlhttp.setRequestHeader("Content-type", "application/json");
            xmlhttp.send(JSON.stringify(Message_obj));
            xmlhttp.onreadystatechange = function() {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    var Response = JSON.parse(xmlhttp.responseText);
                    document.getElementById("Message_Text").innerHTML = Response["message"];
                }
            }
        }
    }
    
};
//
//Update button function
//
var Update = function(){
    var Token = localStorage.getItem("Token");
    var Private_Key =localStorage.getItem("Private_Key");
    var Get_Hash = Crypto.HMAC(Crypto.SHA1, Token, Private_Key);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "/getuserdatatoken?token=" + Token + "&hash=" + Get_Hash, true)//getueserdatabytoken
    xmlhttp.send(null);
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var Response = JSON.parse(xmlhttp.responseText);
            document.getElementById("Changepass_Text").innerHTML = Response["message"];
            var User = JSON.parse(xmlhttp.responseText)
            var Message_Hash = Crypto.HMAC(Crypto.SHA1, User["data"]["email"], Private_Key);
            xmlhttp.open("GET","/getmessageemail?token=" + Token + "&email=" + User["data"]["email"] + "&hash=" + Message_Hash, true )//getusermessageemail
            xmlhttp.send(null);
            xmlhttp.onreadystatechange = function() {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    var Response = JSON.parse(xmlhttp.responseText)
                    if(Response["success"] == true){
                        var Messages_Array = Response["data"];
                        Messages_Array.replace("-", "<br>");
                        document.getElementById("Wall_Content").innerHTML = Messages_Array;
                    }
                    else{
                        document.getElementById("Wall_Content").innerHTML = Response["message"];
                    }
                }
            }
        }
    }

}
//
//Browse search user button function
//
var Search_Submit = function(formData){
    var Token = localStorage.getItem("Token");
    var Private_Key =localStorage.getItem("Private_Key");
    var Email = formData.Search.value
    var xmlhttp = new XMLHttpRequest();
    var Get_Hash = Crypto.HMAC(Crypto.SHA1, Email, Private_Key);
    xmlhttp.open("GET","/getuserdataemail?token=" + Token + "&email=" + Email + "&hash=" + Get_Hash, true )//getueserdatabytoken
    xmlhttp.send(null);
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var Response = JSON.parse(xmlhttp.responseText)
            if(Response["success"] == true){
                document.getElementById("Browse_Panel").innerHTML = document.getElementById("User_View").innerHTML;
                document.getElementById("Found_User_Email").innerHTML = Response["data"]["email"];
                document.getElementById("Found_User_Firstname").innerHTML = Response["data"]["firstname"];
                document.getElementById("Found_User_Familyname").innerHTML = Response["data"]["lastname"];
                document.getElementById("Found_User_Gender").innerHTML = Response["data"]["gender"];
                document.getElementById("Found_User_City").innerHTML = Response["data"]["city"];
                document.getElementById("Found_User_Country").innerHTML = Response["data"]["country"];
                User_Init();

            }
            else{
                document.getElementById("Search_Text").innerHTML = Response["message"];
            }
        }
    }


}
//
//Post on another users wall button function
//
var User_Post_Submit = function(formData){
    var Message = formData.User_Message.value;
    var Token = localStorage.getItem("Token");
    var Private_Key =localStorage.getItem("Private_Key");
    var xmlhttp = new XMLHttpRequest();
    var Get_Hash = Crypto.HMAC(Crypto.SHA1, Token, Private_Key);
    xmlhttp.open("GET", "/getuserdatatoken?token=" + Token + "&hash=" + Get_Hash, true);//getueserdatabytoken
    xmlhttp.send(null);
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var Poster = JSON.parse(xmlhttp.responseText);
            Message += " - " + Poster["data"]["email"] + "\n";
            var User = document.getElementById("Found_User_Email").innerHTML;
            var Message_Hash = Crypto.HMAC(Crypto.SHA1, User + Message, Private_Key);
            var Message_obj = {"token":Token, "message":Message, "email":User, "hash":Message_Hash};
            xmlhttp.open("POST", "/postmessage", true ); //postmessage
            xmlhttp.setRequestHeader("Content-type", "application/json");
            xmlhttp.send(JSON.stringify(Message_obj));
            xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        var Response = JSON.parse(xmlhttp.responseText);
                        document.getElementById("User_Message_Text").innerHTML = Response["message"];
                    }
            }
        }
    }
}
//
//Update another users wall button function
//
var User_Update = function(){
    var User = document.getElementById("Found_User_Email").innerHTML;
    var Token = localStorage.getItem("Token");
    var Private_Key =localStorage.getItem("Private_Key");
    var Get_Hash = Crypto.HMAC(Crypto.SHA1, User, Private_Key);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","/getmessageemail?token=" + Token + "&email=" + User + "&hash=" + Get_Hash, true )//getusermessageemail
    xmlhttp.send(null);
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var Response = JSON.parse(xmlhttp.responseText);
            if(Response["success"] == true){
                var Messages_Array = Response["data"];
                document.getElementById("User_Wall_Content").innerHTML = Messages_Array;
            }
            else{
                document.getElementById("User_Wall_Content").innerHTML = Response["message"];
            }
        }
    }
}
//
//User view back button function
//
var User_Back = function(){
    document.getElementById("Browse_Panel").innerHTML = document.getElementById("Browse_View").innerHTML;
}
//
//Button functions end here
//

//
//Display and fetch related functions bellow
//

//
//Fetch user info and display in the user info column
//
var Disp_Info = function(){
    var Token = localStorage.getItem("Token");
    var Private_Key =localStorage.getItem("Private_Key");
    var Get_Hash = Crypto.HMAC(Crypto.SHA1, Token, Private_Key);
    console.log(Get_Hash)
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "/getuserdatatoken?token=" + Token + "&hash=" + Get_Hash, true)//getueserdatabytoken
    xmlhttp.send(null);
    xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        var User = JSON.parse(xmlhttp.responseText);
                        document.getElementById("User_Email").innerHTML = User["data"]["email"];
                        document.getElementById("User_Firstname").innerHTML = User["data"]["firstname"];
                        document.getElementById("User_Familyname").innerHTML = User["data"]["lastname"];
                        document.getElementById("User_Gender").innerHTML = User["data"]["gender"];
                        document.getElementById("User_City").innerHTML = User["data"]["city"];
                        document.getElementById("User_Country").innerHTML = User["data"]["country"];
                    }
                }

}
//
//Display the home tab
//
var Disp_Home_Tab = function() {
    Init();
    Disp_Info();
    document.getElementById("Home_Panel").style.display = "block";
    document.getElementById("Home_Tab").style.color = "#ffffff";
    document.getElementById("Browse_Tab").style.color = "#555555";
    document.getElementById("Account_Tab").style.color = "#555555";
    document.getElementById("Media_Tab").style.color = "#555555";
    document.getElementById("Browse_Panel").style.display = "none";
    document.getElementById("Account_Panel").style.display = "none";
    document.getElementById("Media_Panel").style.display = "none";
}
//
//Display the browse tab
//
var Disp_Browse_Tab = function() {

    document.getElementById("Home_Panel").style.display = "none";
    document.getElementById("Browse_Panel").style.display = "block";
    document.getElementById("Home_Tab").style.color = "#555555";
    document.getElementById("Browse_Tab").style.color = "#ffffff";
    document.getElementById("Account_Tab").style.color = "#555555";
    document.getElementById("Media_Tab").style.color = "#555555";
    document.getElementById("Account_Panel").style.display = "none";
    document.getElementById("Media_Panel").style.display = "none";

}
//
//Display the account tab
//
var Disp_Account_Tab = function() {
    Profile_Init();
    document.getElementById("Home_Panel").style.display = "none";
    document.getElementById("Browse_Panel").style.display = "none";
    document.getElementById("Media_Panel").style.display = "none";
    document.getElementById("Account_Panel").style.display = "block";
    document.getElementById("Home_Tab").style.color = "#555555";
    document.getElementById("Browse_Tab").style.color = "#555555";
    document.getElementById("Media_Tab").style.color = "#555555";
    document.getElementById("Account_Tab").style.color = "#ffffff";

}
//
//Display the media tab
//
var Disp_Media_Tab = function() {

    document.getElementById("Home_Panel").style.display = "none";
    document.getElementById("Browse_Panel").style.display = "none";
    document.getElementById("Account_Panel").style.display = "none";
    document.getElementById("Media_Panel").style.display = "block";
    document.getElementById("Home_Tab").style.color = "#555555";
    document.getElementById("Browse_Tab").style.color = "#555555";
    document.getElementById("Account_Tab").style.color = "#555555";
    document.getElementById("Media_Tab").style.color = "#ffffff";

}
//
//Profile Image upload function
//
var Profile_Image_Upload = function(file, Token){
    var fd = new FormData();
    var Private_Key =localStorage.getItem("Private_Key");
    var Hash = Crypto.HMAC(Crypto.SHA1, Token, Private_Key);
    var xmlhttp = new XMLHttpRequest();
    fd.append("file", file);
    console.log(fd);
    xmlhttp.open("POST", "/pictureupload?token=" +Token + "&hash=" + Hash, true );//fileupload
    xmlhttp.send(fd);
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var Response = JSON.parse(xmlhttp.responseText);
            console.log(Response["message"]);

        }
    }

}
////
////Post file upload function
////
//var User_Upload_file = function(file, Token, To_email, From_email){
//    var fd = new FormData();
//    var xmlhttp = new XMLHttpRequest();
//    fd.append("file", file);
//    console.log(fd);
//    xmlhttp.open("POST", "/fileupload?token=" + Token + "&to_email=" + To_email + "&from_email=" + From_email, true );//fileupload
//    xmlhttp.send(fd);
//    xmlhttp.onreadystatechange = function() {
//        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
//            var Response = JSON.parse(xmlhttp.responseText);
//            console.log(Response["message"]);
//
//        }
//    }
//}
//
//
//
var Upload_File = function(file, Token, To_email){
    var fd = new FormData();
    var Private_Key =localStorage.getItem("Private_Key");
    var Hash = Crypto.HMAC(Crypto.SHA1, Token + To_email, Private_Key);
    var xmlhttp = new XMLHttpRequest();
    fd.append("file", file);
    console.log(fd);
    xmlhttp.open("POST", "/fileupload?token=" +Token + "&to_email=" + To_email + "&hash=" + Hash, true );//fileupload
    xmlhttp.send(fd);
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var Response = JSON.parse(xmlhttp.responseText);
            console.log(Response["message"]);

        }
    }
}
