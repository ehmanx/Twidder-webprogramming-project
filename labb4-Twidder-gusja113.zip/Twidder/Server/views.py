#
#Author: Gustav Jannering gusja113
#
from flask import Flask, jsonify, request, redirect, url_for, Response
from geventwebsocket.handler import WebSocketHandler
from werkzeug import secure_filename
from flask.ext.bcrypt import Bcrypt
from hashlib import sha1

import database_helper
import random
import json
import __init__
import os
import hmac



app = Flask(__name__)
app.debug = True

userList = {}
UPLOAD_FOLDER = '/home/gusja113/TDDD97/Twidder/Server/media'
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif', 'mp4', 'ogg'])
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.before_request
def before_request():
    database_helper.connect_db()

@app.teardown_request
def teardown_request(exception):
    database_helper.close()


@app.route('/', methods=['get'])
def send_start_page():
    return app.send_static_file("client.html")


@app.route('/ws')
def webSocket():
    ws = request.environ['wsgi.websocket']
    while True:
        token = ws.receive()
        userListCopy = userList
        print token
        email = database_helper.get_online_user_by_token(token)[1]
        print email
        print userList
        for elem in userListCopy:
            if elem == email:
                socket = userListCopy[elem]
                socket.send(json.dumps({'sign_out': True, 'message': 'user has logged in from another browser'}))
        userList[email] = ws
        print userList
        #return 'lol'


@app.route('/signin', methods=['post'])
def sign_in():
    indata = request.get_json(force=True)
    email = indata["email"]
    password = indata["password"]
    user = database_helper.get_user_by_email(str(email))
    bc = Bcrypt(None)
    if user is not None:
            if bc.check_password_hash(user[1], "PaleBlueDot" + email + password):
                letters = "abcdefghiklmnopqrstuvwwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
                token = ""
                private_key = ""
                for i in range(0, 36): # for(int i = 0; i<37; i++)
                    token += letters[random.randint(0, len(letters)-1)]
                    private_key += letters[random.randint(0, len(letters)-1)]
                database_helper.add_online_user(token, email, private_key)
                return json.dumps({'success': True, 'message': 'Successfully signed in.', 'token': token, 'private_key': private_key})
            else:
                return json.dumps({'success': False, 'message': "wrong username or password"})
    else:
        return json.dumps({'success': False, 'message': 'wrong username or password'})


@app.route('/signup', methods=['POST'])
def sign_up():
    indata = request.get_json(force=True)
    email = str(indata['email'])
    password = str(indata['password'])
    firstname = str(indata['firstname'])
    familyname = str(indata['familyname'])
    gender = str(indata['gender'])
    city = str(indata['city'])
    country = str(indata['country'])
    bc = Bcrypt(None)
    pw_hash = bc.generate_password_hash("PaleBlueDot" + email + password)
    if database_helper.get_user_by_email(email) is None:
        if type(email) is str and type(password) and type(firstname) is str and type(familyname) is str and type(gender) is str and type(city) is str and type(country) is str:
                database_helper.add_user(email, pw_hash, firstname, familyname, gender, city, country)
                return json.dumps({"success": True, "message": "Successfully created a new user."})
        else:
            return json.dumps({"success": False, "message": "Form data missing or incorrect type."})
    else:
        return json.dumps({"success": False, "message": "User already exists."})


@app.route('/signout', methods=['post'])
def sign_out():
    indata = request.get_json(force=True)
    token = indata['token']
    indata_hash = indata["hash"]
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    hmac_hash = hmac.new(private_key, str(token), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token) is not None:
            database_helper.delete_online_user(token)
            return json.dumps({"success": True, "message": "Successfully signed out."})
        return json.dumps({"success": False, "message": "You are not signed in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})


@app.route('/changepassword', methods=['post'])
def change_password():
    bc = Bcrypt(None)
    indata = request.get_json(force=True)
    token = indata['token']
    old_password = indata['old_password']
    new_password = indata['new_password']
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    indata_hash = indata["hash"]
    hmac_hash = hmac.new(private_key, str(old_password) + str(new_password), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token) is not None:
            email = database_helper.get_online_user_by_token(token)[1]
            user = database_helper.get_user_by_email(email)
            if bc.check_password_hash(user[1], "PaleBlueDot" + email + old_password):
                new_hash_password = bc.generate_password_hash("PaleBlueDot" + email + new_password)
                database_helper.change_user_password(email, new_hash_password)
                return json.dumps({"success": True, "message": "Password changed."})
            else:
                return json.dumps({"success": False, "message": "Wrong password."})
        else:
            return json.dumps({"success": False, "message": "You are not logged in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})


@app.route('/getuserdatatoken', methods=['get'])
def get_user_data_by_token():
    token = request.args.get('token')
    indata_hash = request.args.get('hash')
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    hmac_hash = hmac.new(private_key, str(token), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token) is not None:
            email = database_helper.get_online_user_by_token(token)[1]
            if database_helper.get_user_by_email(email) is not None:
                user = database_helper.get_user_by_email(email)
                data = {
                    "email": email,
                    "firstname": user[2],
                    "lastname": user[3],
                    "gender": user[4],
                    "city": user[5],
                    "country": user[6]}
                return json.dumps({"success": True, "message": "User data retrieved.", "data": data})
            else:
                return json.dumps({"success": False, "message": "No such user."})
        else:
            return json.dumps({"success": False, "message": "You are not signed in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})

@app.route('/getuserdataemail', methods=['get'])
def get_user_data_by_email():
    email = request.args.get('email')
    token = request.args.get('token')
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    indata_hash = request.args.get('hash')
    hmac_hash = hmac.new(private_key, str(email), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token) is not None:
            if database_helper.get_user_by_email(email) is not None:
                user = database_helper.get_user_by_email(email)
                data = {
                    "email": email,
                    "firstname": user[2],
                    "lastname": user[3],
                    "gender": user[4],
                    "city": user[5],
                    "country": user[6]}
                return json.dumps({"success": True, "message": "User data retrieved.", "data": data})
            else:
                return json.dumps({"success": False, "message": "No such user."})
        else:
            return json.dumps({"success": False, "message": "You are not signed in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})

@app.route('/getmessagetoken', methods=['get'])
def get_user_messages_by_token():
    token = request.args.get('token')
    indata_hash = request.args.get('hash')
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    hmac_hash = hmac.new(private_key, str(token), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token) is not None:
            email = database_helper.get_online_user_by_token(token)[1]
            if database_helper.get_user_by_email(email) is not None:
                messages = database_helper.get_user_by_email(email)[7]
                return json.dumps({"success": True, "message": "User messages retrieved.", "data": messages})
            else:
                return json.dumps({"success": False, "message": "No such user."})
        else:
            return json.dumps({"success": False, "message": "You are not signed in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})


@app.route('/getmessageemail', methods=['get'])
def get_user_messages_by_email():
    email = request.args.get('email')
    token = request.args.get('token')
    indata_hash = request.args.get('hash')
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    hmac_hash = hmac.new(private_key, str(email), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token) is not None:
            if database_helper.get_user_by_email(email) is not None:
                messages = database_helper.get_user_by_email(email)[7]
                return json.dumps({"success": True, "message": "User messages retrieved.", "data": messages})
            else:
                return json.dumps({"success": False, "message": "No such user."})
        else:
            return json.dumps({"success": False, "message": "You are not signed in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})

@app.route('/postmessage', methods=['post'])
def post_message():
    indata = request.get_json(force=True)
    email = indata['email']
    token = indata['token']
    message = indata['message']
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    indata_hash = indata["hash"]
    hmac_hash = hmac.new(str(private_key), str(email) + str(message), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token) is not None:
            if database_helper.get_user_by_email(email) is not None:
                user = database_helper.get_user_by_email(email)
                messages = str(user[7]) + str(message)
                database_helper.post_message(email,messages)
                return json.dumps({"success": True, "message": "Message posted"})
            else:
                return json.dumps({"success": False, "message": "No such user."})
        else:
            return json.dumps({"success": False, "message": "You are not signed in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS


@app.route('/fileupload', methods=['post'])
def file_upload():
    token = request.args.get('token')
    to_email = request.args.get('to_email')
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    from_email = database_helper.get_online_user_by_token(token)[1]
    File = request.files["file"]
    indata_hash = request.args.get('hash')
    hmac_hash = hmac.new(private_key, str(token) + str(to_email), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token):
            if File and allowed_file(File.filename):
                filename = secure_filename(File.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                File.save(file_path)
                database_helper.add_file(str(filename), str(to_email), str(from_email))
                old_messages = database_helper.get_user_by_email(to_email)
                print old_messages
                new_messages = str(old_messages[7]) + " " + str(filename) + " - " + str(from_email)
                database_helper.post_message(to_email, new_messages)
                return json.dumps({"success": True, "message": "File uploaded"})
            else:
                return json.dumps({"success": False, "message": "Failed to save file."})
        else:
            return json.dumps({"success": False, "message": "You are not signed in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})


@app.route('/pictureupload', methods=['post'])
def profile_picture_upload():
    token = request.args.get('token')
    File = request.files["file"]
    email = database_helper.get_online_user_by_token(token)[1]
    indata_hash = request.args.get('hash')
    private_key = str(database_helper.get_online_user_by_token(token)[2])
    hmac_hash = hmac.new(private_key, str(token), sha1)
    if hmac_hash.hexdigest() == indata_hash:
        if database_helper.get_online_user_by_token(token):
            if File and allowed_file(File.filename):
                filename = secure_filename(File.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                File.save(file_path)
                if database_helper.get_profile_piture(email) is None:
                    database_helper.add_profile_picture(str(filename), str(email))
                else:
                    database_helper.change_profile_picture(str(filename), str(email))
                return json.dumps({"success": True, "message": "Picture uploaded"})
            else:
                return json.dumps({"success": False, "message": "Failed to save file."})
        else:
            return json.dumps({"success": False, "message": "You are not signed in."})
    else:
        return json.dumps({"success": False, "message": "I do not trust you! BEGONE."})

