#
#Author: Gustav Jannering gusja113
#
from flask import Flask
from gevent.wsgi import WSGIServer
import werkzeug.serving
from Server.views import app
from geventwebsocket.handler import WebSocketHandler


@werkzeug.serving.run_with_reloader
def run_server():
    app.debug = True
    http_server = WSGIServer(('127.0.0.1', 5000), app, handler_class=WebSocketHandler)
    http_server.serve_forever()


if __name__ == "__main__":
    run_server()